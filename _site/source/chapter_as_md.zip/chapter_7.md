---
layout: page
title: Annex 01. Abkürzungen
nav_order: 7
---
 
<details markdown="block"> 
  <summary> 
      &#9658; Inhaltsverzeichnis Kapitel (ausklappbar) 
  </summary>
 
1. TOC
{:toc}
 </details>
 
   <p></p>
 
 
**ArbMedVV** arbeitsmedizinische Vorsorge

**AsylG** Asylgesetz

**AsylbLG** Asylbewerberleistungsgesetz

**BfArM** Bundesinstitut für Arzneimittel und Medizinprodukte (BfArM) i

**BGB** Bürgerliches Gesetzbuch

**BTHG** Bundesteilhabegesetz

**BKindSchG** Bundeskinderschutzgesetzes

**BVKJ** Berufsverband der Kinder- und Jugendärzte

**BVÖGD** Bundesverbandes der Ärztinnen und Ärzte des Öffentlichen
Gesundheitsdienstes

**BZgA** Bundeszentrale für gesundheitliche Aufklärung

**DGKJ** Deutschen Gesellschaft für Kinder- und Jugendmedizin

**DGSPJ** Deutschen Gesellschaft für Sozialpädiatrie und Jugendmedizin

**FGKiKP** Familienhebammen, Familien-Gesundheits- und
Kinderkrankenpflegerinnen und –pfleger

**IfSG** Infektionsschutzgesetz

**ISSOP** Internationalen Gesellschaft für Sozialpädiatrie (engl.
International Society of Social Pediatrics)

**JArbSchG** Jugendarbeitsschutzgesetz

**KiFöG** Kinderförderungsgesetz

**KJGD** Kinder- und Jugendgesundheitsdienst

**KJPD** Kinder- und Jugendpsychiatrische Dienst

**KKG** Gesetz zur Kooperation und Information im Kinderschutz

**GBA** Gemeinsamen Bundesausschuss

**GBE **Gesundheitsberichterstattung

**GDG** Gesundheitsdienstgesetze 

**GKV** Gesetzlichen Krankenkasse

**HNO** Hals-Nase-Ohren

**ISSOP** Internationalen Gesellschaft für Sozialpädiatrie (engl.
International Society of social pediatrics)

**ÖGD**  Öffentlicher Gesundheitsdienst

**PKV** Private Krankenversicherung

**PrävG** Präventionsgesetz

**Psych(H)KG** Psychiatriekranken(Hilfe)gesetz

**RKI** Robert Koch-Institut

**SGB** Sozialgesetzbuch

**SOPESS** Sozial-Pädiatrische-Entwicklungs-Screening 

**SPDi** Sozialpsychiatrischer Dienst

**SPZ** Sozialpädiatrische Zentren

**STIKO** Ständige Impfkommission

**ZÄD** Zahnärztlicher Dienst

<div class="section fnlist" data-role="doc-footnotes">

</div>
